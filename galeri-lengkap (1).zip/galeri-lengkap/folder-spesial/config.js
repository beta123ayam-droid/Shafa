// ===== FILE YANG KAMU EDIT =====
// Ganti teks di dalam tanda kutip. Biarkan tanda kutip dan koma tetap ada.
window.PENGATURAN = {
  // Alamat aplikasi galeri-polaroid (tanpa garis miring di akhir).
  // Tes di komputer: http://localhost:3000
  // Setelah dihosting: alamat Vercel, misalnya https://galeri-foto.vercel.app
  galeriUrl: 'http://localhost:3000',

  // Nama dia
  nama: 'Nama Dia',

  // Judul di atas nama
  judul: 'Selamat ulang tahun',

  // Pesanmu. Pakai \n untuk pindah baris.
  pesan: 'Ini hadiah kecil untukmu:\ntempat menyimpan foto-foto yang kamu suka.',

  // Tulisan di tombol
  tombol: 'Buka galeri'
};
