# Folder Spesial: Halaman Pembukaan (ucapan ulang tahun)

Halaman yang tampil pertama kali. Tombolnya membawa dia ke halaman login
aplikasi `galeri-polaroid`.

## Yang diedit: hanya `config.js`
Isi `nama`, `pesan`, dan `galeriUrl`. Tidak perlu menyentuh `index.html`.

## Letak folder
    (folder induk)/
      galeri-polaroid/    aplikasi galeri (Next.js)
      folder-spesial/     folder ini
        index.html        tampilan halaman pembukaan
        config.js         nama, pesan, dan alamat galeri

## Tes di komputer
Jalankan `npm run dev` di folder `galeri-polaroid`, lalu buka `index.html`
dengan klik dua kali. Tombol akan membuka halaman login.

## Hosting (proyek Vercel terpisah)
1. Push folder ini ke GitHub (repo sendiri, atau satu repo dengan galeri dan
   Root Directory diatur ke `folder-spesial`).
2. Vercel: Add New > Project > pilih repo > Framework Preset **Other**,
   tanpa build command. Deploy.
3. Ganti `galeriUrl` di `config.js` dengan alamat Vercel galeri, lalu push lagi.

## Menghubungkan sebaliknya (opsional)
Di proyek galeri di Vercel, tambahkan environment variable `LANDING_URL`
berisi alamat halaman ini, lalu Redeploy. Orang yang membuka galeri tanpa
login akan diarahkan ke halaman pembukaan dulu.
