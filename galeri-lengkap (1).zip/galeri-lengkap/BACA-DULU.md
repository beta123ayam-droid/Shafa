# Daftar file yang perlu diedit

1. folder-spesial/config.js
   Ganti: nama, pesan, galeriUrl (alamat Vercel galeri setelah online).

2. Environment Variables di Vercel (proyek galeri-polaroid), bukan file:
   - LOGIN_PASSWORD  : kata kunci untuk dia (wajib)
   - LOGIN_USERNAME  : kosongkan kalau mau login satu kolom
   - SESSION_SECRET  : acak, buat dengan `openssl rand -hex 32`
   - R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET
   - LANDING_URL     : alamat halaman pembukaan (opsional)

3. CORS di bucket Cloudflare R2: ganti NAMA-PROYEKMU dengan domain galeri
   (lihat galeri-polaroid/README.md).

File lain tidak perlu diubah.
