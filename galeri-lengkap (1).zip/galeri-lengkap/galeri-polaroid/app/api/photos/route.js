import { ListObjectsV2Command, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { NextResponse } from 'next/server';
import { getR2, bucket } from '@/lib/r2';
import { isAuthed } from '@/lib/session';

export const dynamic = 'force-dynamic';

export async function GET(request) {
  if (!(await isAuthed(request))) {
    return NextResponse.json({ error: 'Belum login' }, { status: 401 });
  }

  const r2 = getR2();
  const items = [];
  let token;
  do {
    const out = await r2.send(
      new ListObjectsV2Command({ Bucket: bucket(), Prefix: 'photos/', ContinuationToken: token })
    );
    items.push(...(out.Contents || []).filter((o) => o.Key && o.Size > 0));
    token = out.IsTruncated ? out.NextContinuationToken : undefined;
  } while (token);

  // Bucket privat: tiap foto diberi link sementara (6 jam)
  const photos = await Promise.all(
    items.map(async (o) => ({
      key: o.Key,
      lastModified: o.LastModified,
      url: await getSignedUrl(r2, new GetObjectCommand({ Bucket: bucket(), Key: o.Key }), {
        expiresIn: 6 * 60 * 60,
      }),
    }))
  );
  photos.sort((a, b) => new Date(b.lastModified) - new Date(a.lastModified));
  return NextResponse.json({ photos });
}
