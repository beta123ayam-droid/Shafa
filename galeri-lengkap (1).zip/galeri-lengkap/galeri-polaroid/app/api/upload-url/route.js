import { PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { NextResponse } from 'next/server';
import { getR2, bucket } from '@/lib/r2';
import { isAuthed } from '@/lib/session';

const TYPES = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
};

export async function POST(request) {
  if (!(await isAuthed(request))) {
    return NextResponse.json({ error: 'Belum login' }, { status: 401 });
  }

  const { contentType, caption = '' } = await request.json().catch(() => ({}));
  const ext = TYPES[contentType];
  if (!ext) {
    return NextResponse.json({ error: 'Format foto tidak didukung.' }, { status: 400 });
  }

  const clean = String(caption)
    .trim()
    .slice(0, 40)
    .replace(/\s+/g, '_')
    .replace(/[^\w-]/g, '');
  const key = `photos/${Date.now()}__${clean}.${ext}`;

  // Browser mengunggah langsung ke R2 lewat link sementara ini (berlaku 10 menit)
  const url = await getSignedUrl(
    getR2(),
    new PutObjectCommand({ Bucket: bucket(), Key: key, ContentType: contentType }),
    { expiresIn: 600 }
  );
  return NextResponse.json({ url, key });
}
