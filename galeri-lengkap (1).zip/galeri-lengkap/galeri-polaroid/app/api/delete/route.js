import { DeleteObjectCommand } from '@aws-sdk/client-s3';
import { NextResponse } from 'next/server';
import { getR2, bucket } from '@/lib/r2';
import { isAuthed } from '@/lib/session';

export async function POST(request) {
  if (!(await isAuthed(request))) {
    return NextResponse.json({ error: 'Belum login' }, { status: 401 });
  }
  const { key } = await request.json().catch(() => ({}));
  if (typeof key !== 'string' || !key.startsWith('photos/') || key.includes('..')) {
    return NextResponse.json({ error: 'Kunci foto tidak valid.' }, { status: 400 });
  }
  await getR2().send(new DeleteObjectCommand({ Bucket: bucket(), Key: key }));
  return NextResponse.json({ ok: true });
}
