# Galeri Foto Polaroid (Login + Cloudflare R2)

Next.js, halaman login, dan foto disimpan di bucket Cloudflare R2 yang PRIVAT.
Foto hanya tampil setelah login (tiap foto diberi link sementara 6 jam).

## 1. Siapkan Cloudflare R2
1. Dashboard Cloudflare > **R2 Object Storage** > **Create bucket**
   (misal `galeri-foto`). Biarkan privat, jangan aktifkan Public access.
   Cloudflare bisa meminta metode pembayaran saat mengaktifkan R2; tidak ada
   tagihan selama pemakaian masih di dalam kuota gratis.
2. R2 > **Manage API tokens** > **Create API token** > izin
   **Object Read & Write**, batasi ke bucket tadi. Simpan
   **Access Key ID** dan **Secret Access Key** (hanya tampil sekali).
3. **Account ID** ada di halaman R2 (panel kanan) atau di URL dashboard.
4. Bucket > **Settings** > **CORS Policy** > tempel (ganti domainmu):

       [
         {
           "AllowedOrigins": ["https://NAMA-PROYEKMU.vercel.app", "http://localhost:3000"],
           "AllowedMethods": ["PUT"],
           "AllowedHeaders": ["Content-Type"],
           "MaxAgeSeconds": 3600
         }
       ]

   Tanpa CORS ini, upload dari browser akan gagal.

## 2. Deploy ke Vercel
1. Push folder ini ke GitHub, lalu Import di vercel.com.
2. Settings > Environment Variables, isi semua variabel di `.env.example`:
   `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET`,
   `LOGIN_USERNAME`, `LOGIN_PASSWORD`, `SESSION_SECRET`.
   Buat `SESSION_SECRET` dengan perintah `openssl rand -hex 32`
   (atau ketik acak sepanjang 32+ karakter).
3. Deploy / Redeploy.

## Jalankan di komputer
    npm install
    cp .env.example .env.local   # lalu isi nilainya
    npm run dev

## Catatan
- Login memakai satu akun dari environment variable. Sesi berlaku 7 hari.
- Format foto: JPG, PNG, WebP, GIF, maksimal 25 MB per foto.
- Keterangan foto disimpan di nama file (maks. 40 huruf/angka, tanpa aksen).
- Kalau mengganti ke domain lain, perbarui `AllowedOrigins` di CORS.

## Halaman pembukaan (opsional)
Folder `folder-spesial` (sejajar dengan folder ini) berisi halaman pembukaan
sebelum login. Setelah halaman itu online, isi `LANDING_URL` di Environment
Variables proyek ini dengan alamatnya. Detailnya ada di README folder tersebut.
